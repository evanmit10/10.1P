import React, {useState} from "react";
import Button from "./Button";


const handleClick = async()=> {
    await fetch('http://localhost:3007/')
    .then (response => response.json())
    .then(data=> console.log(data))
}

<Button
    type = 'submit'
    onClick = {handleClick}
/>


export default Subscribe;