import React, {useState}  from 'react'
import './style.css';
import './footer.css';
import Input from './Input';
import Button from './Button';

import {FaFacebookSquare, FaInstagram, FaTwitter} from "react-icons/fa"

const HomePage = (props)=>{

    const [contact , setContact] = useState({
        email:''
    })

    const {email} = contact



    const handleClick = async()=> {
        await fetch('http://localhost:8003/', {
            method: 'post',
            headers: {'Content-Type' : 'application/json'},
            body : JSON.stringify({
                email: contact.email
            }) 
        })
        .then (response => response.json())
        .then(data=> JSON.parse(data))
        .catch(err => {
            console.log("Error: " + err)
        })
    }

    const handleChange = (event)=>{
        const {name, value} = event.target
        setContact ((preValue)=>{  
        return {
        ...preValue,
        [name]: value
        }
        })
    }
    
    return (
        <>
        <div style={{padding: "25px", backgroundColor:"lightgray"}}>
        <p style= {{position: "absolute", top: "11px", fontWeight:"bold", fontSize: "30px"}}>Sign up for our Daily Insider</p>
  

  
        <div class="container" >
        <Input 
        name= 'email'
        type= 'text'
        placeholder = 'name'
        onChange = {handleChange}
        value = {contact.email}
        />        
       </div>
  

        <div class="buttons">
            <Button type= "submit" class= "button" value= "Subscribe" onClick={handleClick}>Subscribe</Button>
        </div>
  
        </div>
        
        <div class="footer">
          <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "250px"}}>Explore</p>
          <p style={{position: "absolute", top: "80px", left: "250px"}}>Home</p>
          <p style={{position: "absolute", top: "120px", left: "250px"}}>Questions</p>
          <p style={{position: "absolute", top: "160px", left: "250px"}}>Articles</p>
          <p style={{position: "absolute", top: "200px", left: "250px"}}>Tutorials</p>
  
          <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "760px"}}>Support</p>
          <p style={{position: "absolute", top: "80px", left: "760px"}}>FAQs</p>
          <p style={{position: "absolute", top: "120px", left: "760px"}}>Help</p>
          <p style={{position: "absolute", top: "160px", left: "760px"}}>Contact Us</p>
  
          <p style={{position: "absolute", fontWeight:"bold", top: "20px", left: "1260px"}}>Stay Connected</p>
          <FaFacebookSquare style={{position: "absolute", left: "1210px", top: "80px"}} href="#" class="icons"/>
          <FaInstagram style={{position: "absolute", left: "1310px", top: "80px"}} href="#" class="icons"/>
          <FaTwitter style={{position: "absolute", left: "1410px", top: "80px"}} href="#" class="icons"/>
  
          <p style={{position: "absolute", fontWeight:"bold", top: "280px", left: "732px"}}>DEV@Deakin 2022</p>
          <p style={{position: "absolute", top: "340px", left: "500px"}}>Privacy Policy</p>
          <p style={{position: "absolute", top: "340px", left: "780px"}}>Terms</p>
          <p style={{position: "absolute", top: "340px", left: "1000px"}}>Code of Conduct</p>
  
        </div>
        </>
        
    );
   
}

export default HomePage;