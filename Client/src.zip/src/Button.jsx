import React from "react";
import './style.css';

const Button = (props) => {
    return <button style={{position: "absolute", top:"36px", width:"7.8%"}} type = {props.type} class = {props.class} value = {props.value} onClick = {props.onClick}>Subscribe</button>
}

export default Button;